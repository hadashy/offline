Import-Module HysolateWorkspace

$PackageName = "SetGoogleChromeAsDefault"
$EXEFile = "${PSScriptRoot}\SetDefaultBrowser.exe"

New-MessageLogger -Level "Information" -Default -LogFileName "${PackageName}_Install.log" -EnableConsoleLog | Out-Null

# "install" SetDefaultBrowser utility
$installPath = "${env:SystemDrive}\Programs\Tools"
if (-not (Test-Path "${installPath}")) {
  Write-InfoLog "Creating folder: ${installPath}"
  New-Item -ItemType Directory -Path "${installPath}" | Out-Null
}
Write-InfoLog "Copying file: ${EXEFile} --> ${installPath}\"
Copy-Item -Path "${EXEFile}" -Destination "${installPath}\"

# schedule utility to run at logon
New-ScheduledLogonTask -TaskName "${PackageName}" -GroupId "BUILTIN\Users" -Command "${EXEFile}" -Arguments "chrome" | Out-Null
